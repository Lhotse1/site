Electronics Retailer - Sales Performance Model
=============================================

WHAT'S IN HERE

  electronics-retailer.xlsx   The model and dashboard
  data/                       Six source CSV files


JUST WANT TO LOOK AROUND?

Open electronics-retailer.xlsx. Everything works straight away -
the dashboard, the PivotTables and all the measures. The Data Model
is saved inside the workbook, so you do not need the CSV files to
explore it.


WANT TO REFRESH IT YOURSELF?

Keep the data folder in the same place, next to the workbook, then:

  Data -> Refresh All

The queries find the CSV files relative to wherever you have saved
the workbook, so you can move the whole folder anywhere you like.
Just keep the workbook and the data folder together.

If Excel asks about data privacy levels, allow it. That prompt
appears because the queries read the workbook's own folder path to
locate the CSV files.


HOW IT IS PUT TOGETHER

  Power Query    Loads and cleans the six CSVs, adds the customer
                 age banding, and builds a date calendar
  Data Model     Star schema - a Sales fact table joined to
                 Customers, Products, Stores, Calendar and
                 Exchange Rates dimensions
  Power Pivot    DAX measures for orders, revenue, average order
                 value and delivery time

The source data is a free sample dataset for a fictional retailer.
No real company or customer information is included.
